
# 상품관리 CRUD 작성 

## Product* 접두사 클래스, 인터페이스 생성
### 진행순서

1. ProductDTO 생성
2. mybatis-config.xml에 alias 선언
3. ProductDao 생성, product-mapper.xml 생성
4. ProductController, ProductService 생성
5. product/list.jsp, product/input.jsp, product/view.jsp
6. css 는 필요에 따라 생성

 