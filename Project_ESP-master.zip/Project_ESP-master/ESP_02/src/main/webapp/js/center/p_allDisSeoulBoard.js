function field_focus(field, searchVal){

    if(field.value == searchVal){
        
        field.value = '';
    }
}


function field_blur(field, searchVal){

    if(field.value  == ''){
        field.value = searchVal;
    }
}
